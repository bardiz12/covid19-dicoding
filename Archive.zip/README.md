# Pantau Covid-19

Mobile First Website untuk memantau Statistik Covid-19 di Indonesia

# Demo
visit [https://covid19-dicoding.netlify.app/](https://covid19-dicoding.netlify.app/) to see the demo of this project
![Demo Gif](demo.gif)
